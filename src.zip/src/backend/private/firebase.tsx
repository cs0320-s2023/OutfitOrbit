const API_KEY :string =  "AIzaSyBWkPMhoK-HrmmEeAqwCO0JdUFf0qXP4oU";
const AUTH_DOMAIN: string = "outfitorbit-13937.firebaseapp.com";
const PROJECT_ID: string = "outfitorbit-13937";
const STORAGE_BUCKET: string = "outfitorbit-13937.appspot.com";
const MESSAGING_SENDER_ID: string = "747178373923";
const APP_ID: string = "1:747178373923:web:12a234a787bdb709b79296";
const MEASUREMENT_ID: string = "G-1670ZM3E44"

export {API_KEY, AUTH_DOMAIN, PROJECT_ID, STORAGE_BUCKET, MESSAGING_SENDER_ID, APP_ID, MEASUREMENT_ID}
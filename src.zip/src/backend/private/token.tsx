let OPEN_API_KEY: string = "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";
export default OPEN_API_KEY;

let OPEN_API_KEY: string = "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";
export default OPEN_API_KEY;

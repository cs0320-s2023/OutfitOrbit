let OPEN_API_KEY: string = "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";
export default OPEN_API_KEY;

let CLIENT_ID: string = "710399342030-beloo1kdrp3efkvj9npf46nbghg00041.apps.googleusercontent.com";
// let CLIENT_SECRET: string = "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";
export default CLIENT_ID;